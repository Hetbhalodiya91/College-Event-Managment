from django.db import models   # import models module to create database models
from django.contrib.auth.models import User
from django.utils import timezone
from datetime import datetime, time as dt_time

class StudentProfile(models.Model):
    BRANCH_CHOICES = [
        ('CSE', 'Computer Science Engineering'),
        ('ECE', 'Electronics and Communication Engineering'),
        ('EEE', 'Electrical and Electronics Engineering'),
        ('ME', 'Mechanical Engineering'),
        ('CE', 'Civil Engineering'),
        ('IT', 'Information Technology'),
        ('AI', 'Artificial Intelligence'),
        ('DS', 'Data Science'),
        ('OTHER', 'Other'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='student_profile')
    roll_no = models.CharField(max_length=20, unique=True, help_text="Student Roll Number")
    college_id = models.CharField(max_length=50, unique=True, help_text="College ID/Registration Number")
    branch = models.CharField(max_length=10, choices=BRANCH_CHOICES, default='CSE')
    semester = models.PositiveIntegerField(null=True, blank=True, help_text="Current Semester")
    phone = models.CharField(max_length=15, blank=True, help_text="Contact Number")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Student Profile"
        verbose_name_plural = "Student Profiles"
        ordering = ['roll_no']
    
    def __str__(self):
        return f"{self.user.username} - {self.roll_no}"

class Event(models.Model):
    CATEGORY_CHOICES = [
        ('TECH', 'Technical'),
        ('CUL', 'Cultural'),
        ('SPORT', 'Sports'),
        ('OTH', 'Other'),
    ]

    title = models.CharField(max_length=200)
    description = models.TextField()
    date = models.DateField()
    time = models.TimeField(null=True, blank=True)
    venue = models.CharField(max_length=200, blank=True)
    capacity = models.PositiveIntegerField(default=0)  # max seats
    category = models.CharField(max_length=10, choices=CATEGORY_CHOICES, default='OTH')
    created_at = models.DateTimeField(auto_now_add=True)
    available_seats = models.PositiveIntegerField(default=0)
    image = models.ImageField(upload_to='event_images/', null=True, blank=True, help_text="Event image")

    def __str__(self):
        return self.title

    def seats_left(self):
        # number of seats left = capacity - number of registrations
        return self.capacity - self.registration_set.count()
    
    def average_rating(self):
        """Calculate average rating from all reviews"""
        reviews = self.reviews.all()
        if reviews.exists():
            return round(sum(review.rating for review in reviews) / reviews.count(), 1)
        return 0.0
    
    def review_count(self):
        """Get total number of reviews"""
        return self.reviews.count()
    
    def get_event_datetime(self):
        """Get the event datetime by combining date and time"""
        if self.time:
            event_datetime = datetime.combine(self.date, self.time)
        else:
            # If no time specified, use end of day (11:59 PM)
            event_datetime = datetime.combine(self.date, dt_time(23, 59, 59))
        return timezone.make_aware(event_datetime, timezone.get_current_timezone())
    
    def is_registration_open(self):
        """Check if registration is still open (event hasn't started yet)"""
        event_datetime = self.get_event_datetime()
        return timezone.now() < event_datetime
    
    def is_past(self):
        """Return True if the event date/time has already passed"""
        event_datetime = self.get_event_datetime()
        return timezone.now() > event_datetime


class Registration(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    registered_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'event')  # user can't register twice

    def __str__(self):
        return f"{self.user.username} -> {self.event.title}"


class Review(models.Model):
    """Reviews for events with ratings"""
    RATING_CHOICES = [
        (1, '1 Star'),
        (2, '2 Stars'),
        (3, '3 Stars'),
        (4, '4 Stars'),
        (5, '5 Stars'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reviews')
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='reviews')
    rating = models.PositiveIntegerField(choices=RATING_CHOICES, default=5)
    title = models.CharField(max_length=200, help_text="Review title")
    content = models.TextField(help_text="Your review")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ('user', 'event')  # User can only review an event once
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.event.title} ({self.rating} stars)"


class Comment(models.Model):
    """Comments on events (multiple per user)"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='comments')
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='comments')
    content = models.TextField(max_length=1000, help_text="Your comment")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} commented on {self.event.title}"


class Favorite(models.Model):
    """User favorites/bookmarks for events"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='favorites')
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='favorites')
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('user', 'event')  # User can only favorite an event once
    
    def __str__(self):
        return f"{self.user.username} favorited {self.event.title}"
