from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Event, StudentProfile, Review, Comment

class EventForm(forms.ModelForm):
    class Meta:
        model = Event
        fields = ['title', 'description', 'date', 'time', 'venue', 'capacity', 'category']

class StudentSignupForm(UserCreationForm):
    # User fields
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={'class': 'w-full px-4 py-2 border rounded-lg'}))
    first_name = forms.CharField(max_length=30, required=False, widget=forms.TextInput(attrs={'class': 'w-full px-4 py-2 border rounded-lg'}))
    last_name = forms.CharField(max_length=30, required=False, widget=forms.TextInput(attrs={'class': 'w-full px-4 py-2 border rounded-lg'}))
    
    # Student profile fields
    roll_no = forms.CharField(max_length=20, required=True, widget=forms.TextInput(attrs={'class': 'w-full px-4 py-2 border rounded-lg', 'placeholder': 'Enter Roll Number'}))
    college_id = forms.CharField(max_length=50, required=True, widget=forms.TextInput(attrs={'class': 'w-full px-4 py-2 border rounded-lg', 'placeholder': 'Enter College ID'}))
    branch = forms.ChoiceField(choices=StudentProfile.BRANCH_CHOICES, required=True, widget=forms.Select(attrs={'class': 'w-full px-4 py-2 border rounded-lg'}))
    semester = forms.IntegerField(required=False, min_value=1, max_value=8, widget=forms.NumberInput(attrs={'class': 'w-full px-4 py-2 border rounded-lg', 'placeholder': 'Current Semester (1-8)'}))
    phone = forms.CharField(max_length=15, required=False, widget=forms.TextInput(attrs={'class': 'w-full px-4 py-2 border rounded-lg', 'placeholder': 'Contact Number'}))
    
    class Meta:
        model = User
        fields = ('username', 'email', 'first_name', 'last_name', 'password1', 'password2', 
                  'roll_no', 'college_id', 'branch', 'semester', 'phone')
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Add Tailwind classes to default fields
        self.fields['username'].widget.attrs.update({'class': 'w-full px-4 py-2 border rounded-lg'})
        self.fields['password1'].widget.attrs.update({'class': 'w-full px-4 py-2 border rounded-lg'})
        self.fields['password2'].widget.attrs.update({'class': 'w-full px-4 py-2 border rounded-lg'})
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        if commit:
            user.save()
            StudentProfile.objects.create(
                user=user,
                roll_no=self.cleaned_data['roll_no'],
                college_id=self.cleaned_data['college_id'],
                branch=self.cleaned_data['branch'],
                semester=self.cleaned_data.get('semester'),
                phone=self.cleaned_data.get('phone', '')
            )
        return user

class StudentProfileForm(forms.ModelForm):
    class Meta:
        model = StudentProfile
        fields = ['roll_no', 'college_id', 'branch', 'semester', 'phone']
        widgets = {
            'roll_no': forms.TextInput(attrs={'class': 'w-full px-4 py-2 border rounded-lg'}),
            'college_id': forms.TextInput(attrs={'class': 'w-full px-4 py-2 border rounded-lg'}),
            'branch': forms.Select(attrs={'class': 'w-full px-4 py-2 border rounded-lg'}),
            'semester': forms.NumberInput(attrs={'class': 'w-full px-4 py-2 border rounded-lg'}),
            'phone': forms.TextInput(attrs={'class': 'w-full px-4 py-2 border rounded-lg'}),
        }


class ReviewForm(forms.ModelForm):
    """Form for creating/editing event reviews"""
    class Meta:
        model = Review
        fields = ['rating', 'title', 'content']
        widgets = {
            'rating': forms.Select(attrs={'class': 'w-full px-4 py-2 border rounded-lg'}),
            'title': forms.TextInput(attrs={'class': 'w-full px-4 py-2 border rounded-lg', 'placeholder': 'Review title'}),
            'content': forms.Textarea(attrs={'class': 'w-full px-4 py-2 border rounded-lg', 'rows': 5, 'placeholder': 'Write your review here...'}),
        }
        labels = {
            'rating': 'Rating',
            'title': 'Review Title',
            'content': 'Your Review',
        }


class CommentForm(forms.ModelForm):
    """Form for creating event comments"""
    class Meta:
        model = Comment
        fields = ['content']
        widgets = {
            'content': forms.Textarea(attrs={'class': 'w-full px-4 py-2 border rounded-lg', 'rows': 3, 'placeholder': 'Write your comment here...'}),
        }
        labels = {
            'content': 'Comment',
        }
