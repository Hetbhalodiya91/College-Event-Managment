from django.contrib import admin
from .models import Event, Registration, StudentProfile, Review, Comment, Favorite

@admin.register(StudentProfile)
class StudentProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'roll_no', 'college_id', 'branch', 'semester', 'phone', 'created_at')
    list_filter = ('branch', 'semester')
    search_fields = ('user__username', 'roll_no', 'college_id', 'user__email')
    readonly_fields = ('created_at', 'updated_at')

@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ('title', 'date', 'venue', 'capacity', 'category', 'average_rating', 'review_count')
    list_filter = ('category', 'date', 'created_at')
    search_fields = ('title', 'description', 'venue') 
    readonly_fields = ('created_at',)

@admin.register(Registration)
class RegistrationAdmin(admin.ModelAdmin):
    list_display = ('user', 'event', 'registered_at')
    list_filter = ('registered_at',)
    search_fields = ('user__username', 'event__title')

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('user', 'event', 'rating', 'title', 'created_at')
    list_filter = ('rating', 'created_at')
    search_fields = ('user__username', 'event__title', 'title', 'content')
    readonly_fields = ('created_at', 'updated_at')

@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ('user', 'event', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('user__username', 'event__title', 'content')
    readonly_fields = ('created_at', 'updated_at')

@admin.register(Favorite)
class FavoriteAdmin(admin.ModelAdmin):
    list_display = ('user', 'event', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('user__username', 'event__title')
