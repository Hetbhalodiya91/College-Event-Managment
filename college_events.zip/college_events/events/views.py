from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.views import LogoutView
from django.core.paginator import Paginator
from django.db.models import Q
from django.utils import timezone

from .models import Event, Registration, StudentProfile, Review, Comment, Favorite
from .forms import StudentSignupForm, StudentProfileForm, ReviewForm, CommentForm



def event_list(request):
    events = Event.objects.all()
    
    # Search functionality
    search_query = request.GET.get('search', '')
    category_filter = request.GET.get('category', '')
    date_filter = request.GET.get('date_filter', '')
    
    if search_query:
        events = events.filter(
            Q(title__icontains=search_query) |
            Q(description__icontains=search_query) |
            Q(venue__icontains=search_query)
        )
    
    if category_filter:
        events = events.filter(category=category_filter)
    
    if date_filter == 'upcoming':
        events = events.filter(date__gte=timezone.now().date())
    elif date_filter == 'past':
        events = events.filter(date__lt=timezone.now().date())
    
    # Sort by date (upcoming first)
    events = events.order_by('date')
    
    # Pagination
    paginator = Paginator(events, 10)  # Show 10 events per page
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'events': page_obj,
        'search_query': search_query,
        'category_filter': category_filter,
        'date_filter': date_filter,
        'categories': Event.CATEGORY_CHOICES,
    }
    return render(request, 'events/list.html', context)
    # return render(request, 'index.html')

def event_detail(request, event_id):
    event = get_object_or_404(Event, pk=event_id)
    is_registered = False
    is_favorited = False
    user_review = None
    
    if request.user.is_authenticated:
        is_registered = Registration.objects.filter(user=request.user, event=event).exists()
        is_favorited = Favorite.objects.filter(user=request.user, event=event).exists()
        user_review = Review.objects.filter(user=request.user, event=event).first()
    
    # Check if registration is open
    is_registration_open = event.is_registration_open()
    is_past = event.is_past()
    
    # Get all reviews and comments
    reviews = Review.objects.filter(event=event).select_related('user')[:10]  # Latest 10 reviews
    comments = Comment.objects.filter(event=event).select_related('user')[:20]  # Latest 20 comments
    
    # Forms
    review_form = ReviewForm() if request.user.is_authenticated else None
    comment_form = CommentForm() if request.user.is_authenticated else None
    
    context = {
        'event': event,
        'is_registered': is_registered,
        'is_favorited': is_favorited,
        'is_registration_open': is_registration_open,
        'is_past': is_past,
        'reviews': reviews,
        'comments': comments,
        'review_form': review_form,
        'comment_form': comment_form,
        'user_review': user_review,
        'average_rating': event.average_rating(),
        'review_count': event.review_count(),
    }
    return render(request, 'events/detail.html', context)

@login_required
def register_event(request, event_id):
    event = get_object_or_404(Event, pk=event_id)

    # Check if event time is over (registration closed)
    if not event.is_registration_open():
        messages.error(request, "Registration closed! This event has already started or passed. You cannot register for past events.")
        return redirect('events:detail', event_id=event.id)

    # Check capacity
    if event.capacity and event.seats_left() <= 0:
        messages.error(request, "Sorry, this event is full.")
        return redirect('events:detail', event_id=event.id)

    # Create registration if not exists
    reg, created = Registration.objects.get_or_create(user=request.user, event=event)
    if created:
        messages.success(request, "You have successfully registered.")
    else:
        messages.info(request, "You are already registered for this event.")

    return redirect('events:my_events')

@login_required
def my_events(request):
    regs = Registration.objects.filter(user=request.user).select_related('event').order_by('-registered_at')
    events = [r.event for r in regs]
    
    # Separate upcoming and past events using is_past() method (more accurate than date comparison)
    upcoming_events = [e for e in events if not e.is_past()]
    past_events = [e for e in events if e.is_past()]
    
    return render(request, 'events/my_events.html', {
        'events': events,
        'upcoming_events': upcoming_events,
        'past_events': past_events,
        'registrations': regs
    })

@login_required
def cancel_registration(request, event_id):
    """Cancel registration for an event"""
    event = get_object_or_404(Event, pk=event_id)
    registration = Registration.objects.filter(user=request.user, event=event).first()

    if event.is_past():
        messages.error(request, "You cannot cancel registration for past events.")
        return redirect('events:my_events')
    
    if registration:
        registration.delete()
        messages.success(request, f"You have successfully cancelled your registration for '{event.title}'.")
    else:
        messages.error(request, "You are not registered for this event.")
    
    return redirect('events:my_events')

def signup_view(request):
    if request.method == 'POST':
        form = StudentSignupForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Account created successfully! Please log in.')
            return redirect('accounts:login')  # Redirect to login page after successful signup
    else:
        form = StudentSignupForm()
    return render(request, 'registration/signup.html', {'form': form})

@login_required
def profile_view(request):
    """Display and edit student profile"""
    try:
        profile = request.user.student_profile
    except StudentProfile.DoesNotExist:
        # If profile doesn't exist, create one
        profile = StudentProfile.objects.create(user=request.user)
    
    if request.method == 'POST':
        form = StudentProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('events:profile')
    else:
        form = StudentProfileForm(instance=profile)
    
    return render(request, 'events/profile.html', {
        'form': form,
        'profile': profile,
        'user': request.user
    })

def logout_view(request):
    logout(request)
    messages.success(request, 'You have been logged out successfully.')
    return redirect('events:list')


@login_required
def add_review(request, event_id):
    """Add or update a review for an event"""
    event = get_object_or_404(Event, pk=event_id)
    
    # Check if user has registered/attended the event (optional - you can remove this check)
    # For now, any authenticated user can review
    
    # Check if user already has a review
    review = Review.objects.filter(user=request.user, event=event).first()
    
    if request.method == 'POST':
        form = ReviewForm(request.POST, instance=review)
        if form.is_valid():
            review = form.save(commit=False)
            review.user = request.user
            review.event = event
            review.save()
            messages.success(request, 'Your review has been submitted successfully!')
            return redirect('events:detail', event_id=event.id)
    else:
        form = ReviewForm(instance=review)
    
    return render(request, 'events/review_form.html', {
        'form': form,
        'event': event,
        'review': review
    })
@login_required
def past_events(request):
    now = timezone.localtime()
    current_date = now.date()
    current_time = now.time()

    past_events = Event.objects.filter(
        date__lt=current_date
    ) | Event.objects.filter(
        date=current_date, time__lt=current_time
    )

    past_events = past_events.order_by('-date', '-time')
    return render(request, 'events/past_event.html', {'past_events': past_events})

@login_required
def delete_review(request, review_id):
    """Delete a review"""
    review = get_object_or_404(Review, pk=review_id, user=request.user)
    event_id = review.event.id
    review.delete()
    messages.success(request, 'Your review has been deleted.')
    return redirect('events:detail', event_id=event_id)


@login_required
def add_comment(request, event_id):
    """Add a comment to an event"""
    event = get_object_or_404(Event, pk=event_id)
    
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.user = request.user
            comment.event = event
            comment.save()
            messages.success(request, 'Your comment has been added!')
            return redirect('events:detail', event_id=event.id)
    
    return redirect('events:detail', event_id=event.id)


@login_required
def delete_comment(request, comment_id):
    """Delete a comment"""
    comment = get_object_or_404(Comment, pk=comment_id, user=request.user)
    event_id = comment.event.id
    comment.delete()
    messages.success(request, 'Your comment has been deleted.')
    return redirect('events:detail', event_id=event_id)


@login_required
def toggle_favorite(request, event_id):
    """Add or remove event from favorites"""
    event = get_object_or_404(Event, pk=event_id)
    favorite, created = Favorite.objects.get_or_create(user=request.user, event=event)
    
    if not created:
        # Already favorited, remove it
        favorite.delete()
        messages.success(request, f'"{event.title}" removed from favorites.')
    else:
        messages.success(request, f'"{event.title}" added to favorites!')
    
    return redirect('events:detail', event_id=event.id)


@login_required
def my_favorites(request):
    """Display user's favorite events"""
    favorites = Favorite.objects.filter(user=request.user).select_related('event').order_by('-created_at')
    events = [f.event for f in favorites]
    
    return render(request, 'events/favorites.html', {
        'favorites': favorites,
        'events': events,
    })