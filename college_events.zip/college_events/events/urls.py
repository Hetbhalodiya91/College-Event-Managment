from django.urls import path
from django.urls import include
from django.contrib.auth import views as auth_views
from django.views.generic import TemplateView
from django.contrib.auth import logout
from django.contrib.auth.views import LogoutView


from . import views

app_name = 'events'

urlpatterns = [
    path('', views.event_list, name='list'),
    path('event/<int:event_id>/', views.event_detail, name='detail'),
    path('event/<int:event_id>/register/', views.register_event, name='register'),
    path('event/<int:event_id>/cancel/', views.cancel_registration, name='cancel_registration'),
    path('event/<int:event_id>/favorite/', views.toggle_favorite, name='toggle_favorite'),
    path('event/<int:event_id>/review/', views.add_review, name='add_review'),
    path('event/<int:event_id>/comment/', views.add_comment, name='add_comment'),
    path('review/<int:review_id>/delete/', views.delete_review, name='delete_review'),
    path('comment/<int:comment_id>/delete/', views.delete_comment, name='delete_comment'),
    path('past-events/', views.past_events, name='past_events'),
    path('logout/', views.logout_view, name='logout'),
    path('my-events/', views.my_events, name='my_events'),
    path('my-favorites/', views.my_favorites, name='my_favorites'),
    path('signup/', views.signup_view, name='signup'),
    path('profile/', views.profile_view, name='profile'),
    # path('accounts/', include('django.contrib.auth.urls')),  # login/logout
]
